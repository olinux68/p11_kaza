// Importation des composants nécessaires
import React from "react";
import { NavLink } from "react-router-dom"; // Importation du composant NavLink pour la navigation
import logo from "./../assets/img/Logo.png"; // Importation du logo

// Initialisation de la liste des liens de navigation
// Cette liste est définie en dehors du composant pour éviter de la recréer à chaque rendu
const navLinks = [
  { to: "/", label: "Accueil" },
  { to: "/about", label: "A Propos" },
];

// Déclaration du composant Nav
const Nav = () => {
  // Le composant retourne un élément header qui contient le logo et la barre de navigation
  // La barre de navigation est une liste non ordonnée de liens NavLink
  // Chaque lien est généré par la méthode map directement dans le JSX
  return (
    <header className="header">
      <div className="header__logo">
        <NavLink to="/">
          <img src={logo} alt="Logo de l'entreprise Kasa" />
        </NavLink>
      </div>
      <nav className="header__nav">
        <ul className="header__nav__ul">
          {navLinks.map(({ to, label }, index) => (
            <NavLink
              key={index} // Utilisation de l'index comme clé
              to={to} // Utilisation de la propriété 'to' comme destination du lien
              className={(nav) => (nav.isActive ? "header__nav__ul--active" : "")} // Ajout d'une classe conditionnelle en fonction de l'état du lien
            >
              <li>{label}</li> {/* Utilisation de la propriété 'label' comme contenu du lien */}
            </NavLink>
          ))}
        </ul>
      </nav>
    </header>
  );
};

// Exportation du composant Nav pour qu'il puisse être utilisé dans d'autres fichiers
export default Nav;
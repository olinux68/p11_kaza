// Importation des hooks nécessaires depuis la bibliothèque React
import React, { useEffect, useState } from "react";
// Importation des images pour les flèches de navigation du slider
import arrowLeft from "./../assets/img/arrowLeft.png";
import arrowRight from "./../assets/img/arrowRight.png";

// Déclaration du composant Slider
const Slider = (props) => {
  // Initialisation de l'état 'index' à 0. Cet état représente l'index de l'image actuellement affichée dans le slider
  const [index, setIndex] = useState(0);
  // Initialisation de l'état 'pics' avec les images passées en props. Cet état représente la liste des images à afficher dans le slider
  const [pics, setPics] = useState([props.pics]);

  // Utilisation de l'effet pour mettre à jour l'état 'pics' chaque fois que les props changent
  useEffect(() => {
    setPics(props.pics);
  }, [props]);

  // Calcul de la longueur de la liste des images
  let length = pics?.length;

  // Déclaration de la fonction clickLeft qui est appelée lorsque l'utilisateur clique sur la flèche gauche du slider
  // Cette fonction décrémente l'index ou le ramène à la fin si l'index est à 0
  function clickLeft() {
    setIndex(index === 0 ? length - 1 : index - 1);
  }

  // Déclaration de la fonction clickRight qui est appelée lorsque l'utilisateur clique sur la flèche droite du slider
  // Cette fonction incrémente l'index ou le ramène au début si l'index est à la fin
  function clickRight() {
    setIndex(index === length - 1 ? 0 : index + 1);
  }

  // Le composant retourne une structure de divs qui représente le slider
  // Si la longueur de la liste des images est supérieure à 1, les flèches de navigation sont affichées
  // L'image actuellement affichée est celle à l'index actuel de la liste des images
  // Le compteur affiche l'index actuel plus 1 et la longueur de la liste des images
  return (
    <div className="slider">
      <div className="slider__container">
        {length > 1 && (
          <div onClick={clickLeft} className="slider__container--left">
            <img
              className="slider__container--left--pic"
              src={arrowLeft}
              alt="slider a gauche"
            />
          </div>
        )}
        <img className="slider__container__image" src={pics?.[index]} alt="" />
        <div className="slider__container__count">
          <p>
            {index + 1}/{length}
          </p>
        </div>
        {length > 1 && (
          <div onClick={clickRight} className="slider__container--right">
            <img
              className="slider__container--right--pic"
              src={arrowRight}
              alt="slider a droite"
            />
          </div>
        )}
      </div>
    </div>
  );
};

// Exportation du composant Slider pour qu'il puisse être utilisé dans d'autres fichiers
export default Slider;
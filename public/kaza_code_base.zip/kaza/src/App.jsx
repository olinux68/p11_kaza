import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import About from "./pages/About";
import P404 from "./pages/Page404";
import Fiche from "./pages/Fiche";
import Home from "./pages/Home";

const routes = [
  { path: "/", element: <Home /> },
  { path: "/about", element: <About /> },
  { path: "/fiche/:appartementId", element: <Fiche /> },
  { path: "*", element: <P404 /> },
];

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        {routes.map((route, index) => (
          <Route key={index} path={route.path} element={route.element} />
        ))}
      </Routes>
    </BrowserRouter>
  );
};

export default App;
// Importation des composants et des données nécessaires
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Footer from "../components/Footer";
import Nav from "../components/Nav";
import logements from "./../assets/data/logements.json";
import { Tag } from "../components/Tag";
import { Rating } from "../components/Rating";
import Slider from "../components/Slider";
import { TopPage } from "../components/Util/TopPage";
import Collapse from "../components/Collapse";

// Déclaration du composant Fiche
const Fiche = () => {
  // Initialisation de l'état 'appartement' avec un objet vide
  const [appartement, setAppartement] = useState({});
  // Récupération de l'id de l'appartement depuis les paramètres de l'URL
  const { appartementId } = useParams();
  // Initialisation de la fonction navigate pour la navigation programmée
  const navigate = useNavigate();

  // Utilisation de l'effet pour appeler la fonction getApparts au montage du composant
  useEffect(() => {
    getApparts();
  });

  // Déclaration de la fonction getApparts qui récupère les informations de l'appartement correspondant à l'id
  const getApparts = () => {
    const newAppartement = logements.find((appart) => appart.id === appartementId);
    if (newAppartement) {
      setAppartement(newAppartement);
    } else {
      navigate("/404");
    }
  };

  // Le composant retourne une structure de divs qui représente la fiche de l'appartement
  // Cette fiche contient un slider avec les images de l'appartement, les informations de l'appartement, les tags de l'appartement, les informations du vendeur, la note de l'appartement et les équipements de l'appartement
  return (
    <div>
      <TopPage />
      <Nav />
      <main className="fiche">
        <div className="fiche__slider">
          <Slider pics={appartement.pictures} />
        </div>
        <div className="fiche__info">
          <div className="fiche__info__title">
            <h1 className="fiche__info__title--h1">{appartement.title}</h1>
            <p className="fiche__info__title--ville">{appartement.location}</p>
            <div className="fiche__tags">
              <div className="fiche__tags__container">
                {appartement.tags?.map((tag) => (
                  <div className="fiche__tags__container--tag" key={tag}>
                    <Tag tag={tag} />
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="fiche__info__vendeur">
            <div className="fiche__info__vendeur--profil">
              <p className="fiche__info__vendeur--profil--name">
                {appartement.host?.name}
              </p>
              <img
                className="fiche__info__vendeur--profil--photo"
                src={appartement.host?.picture}
                alt={appartement.host?.name}
              ></img>
            </div>
            <div className="fiche__tags--note">
              <Rating rate={appartement.rating} />
            </div>
          </div>
        </div>

        <div className="fiche__collapse">
          <div
            className="fiche__collapse--description"
            key={appartement.description}
          >
            <Collapse object={appartement} content={appartement.description} />
          </div>
          <div
            className="fiche__collapse--equipement"
            key={appartement.equipments}
          >
            <Collapse object={appartement} content={appartement.equipments} />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

// Exportation du composant Fiche pour qu'il puisse être utilisé dans d'autres fichiers
export default Fiche;